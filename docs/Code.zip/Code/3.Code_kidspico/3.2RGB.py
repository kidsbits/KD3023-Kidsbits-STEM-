'''
 * Filename    : RGB
 * Thonny      : Thonny 4.1.4
 * Auther      : http//www.keyestudio.com
'''
from machine import Pin
import time

red = Pin(7, Pin.OUT)
green = Pin(8, Pin.OUT)
blue = Pin(9, Pin.OUT)

while True:
    #RGB LED lights up in red for 1 second
    red.on()      #Red LED light
    time.sleep(1) #dalye 1s
    red.off()     #Red LED off
    
    #RGB LED lights up in green for 1 second
    green.on()
    time.sleep(1)
    green.off()
    
    #RGB LED lights up in blue for 1 second
    blue.on()
    time.sleep(1)
    blue.off()
    
    #RGB LED lights up in white for 1 second
    red.on()
    green.on()
    blue.on()
    time.sleep(1)
    red.off()
    green.off()
    blue.off()