'''
 * Filename    : Four-digit numeral tube
 * Thonny      : Thonny 4.1.4
 * Auther      : http//www.keyestudio.com
'''
from machine import Pin
from TM1650 import ShowNum
import time

while True:
    for i in range(0,999):
        ShowNum(i)
        time.sleep(0.01)