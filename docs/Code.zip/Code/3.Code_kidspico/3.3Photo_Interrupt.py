'''
 * Filename    : Photo_Interrupt
 * Thonny      : Thonny 4.1.4
 * Auther      : http//www.keyestudio.com
'''
from machine import Pin
import time

PI = Pin(3, Pin.IN)
lastState = 0
PushCounter = 0

while True:
    State = PI.value()
    if  State != lastState:
        if State == 1:
            PushCounter += 1
            print(PushCounter) 
    lastState = State