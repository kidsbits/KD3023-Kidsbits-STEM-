'''
 * Filename    : Five-way AD
 * Thonny      : Thonny 4.1.4
 * Auther      : http//www.keyestudio.com
'''
from machine import ADC
import time 

# enable abd configure ADC, range 0-3.3V
key = ADC(26)

while True:
    key_value = key.read_u16()
    print(key_value, end = '')
    # key_value < 10000
    if key_value < 10000: 
        print('  no key  is pressed')
    # 10000 < key_value < 14000
    elif key_value < 14000:
        print('  SW5 is pressed')
    # 14000 < key_value < 27000
    elif key_value < 27000:
        print('  SW4 is pressed')
    # 27000 < key_value < 40000
    elif key_value < 40000:
        print('  SW3 is pressed')
    # 40000 < key_value < 53000
    elif key_value < 53000:
        print('  SW2 is pressed')
    # 53000 < key_value
    else:
        print('  SW1 is pressed')
    time.sleep(0.1)