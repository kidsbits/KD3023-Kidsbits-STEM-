'''
 * Filename    : Manual mode
 * Thonny      : Thonny 4.1.4
 * Auther      : http//www.keyestudio.com
'''
from machine import Pin
import time

touch = Pin(2, Pin.IN)
INA = Pin(14, Pin.OUT)
INB = Pin(15, Pin.OUT)

press = 0

while True:
    if touch.value() == 1 and press == 0:
        INA.value(0)
        INB.value(1)
        press = 1
    elif touch.value() == 1 and press == 1:
        INA.value(0)
        INB.value(0)
        press = 0
    time.sleep(0.1)
