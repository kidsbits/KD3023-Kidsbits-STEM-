'''
 * Filename    : Motor
 * Thonny      : Thonny 4.1.4
 * Auther      : http//www.keyestudio.com
'''
from machine import Pin,PWM
import time
 
# set PWM INA and INB pins
pwm_INA = PWM(Pin(14)) 
pwm_INB = PWM(Pin(15)) 
 
# set PWM frequency. The frequency depends on the motor application.
pwm_INA.freq(500)
pwm_INB.freq(500)
 
# Set the maximum and minimum rotation speed
max_duty = 65535
min_duty = 0
 
# Linear interpolation is used to calculate duty values for different speeds
def calc_duty(speed):
    speed = int(speed * (max_duty - min_duty) / 100 + min_duty)
    return speed
 
# change the rotation speed
def set_speed_INA(speed):
    duty = calc_duty(speed)
    pwm_INA.duty_u16(duty)

# change the rotation speed
def set_speed_INB(speed):
    duty = calc_duty(speed)
    pwm_INB.duty_u16(duty)

while True:
    #speed 50, counterclockwise rotate for 2s
    set_speed_INA(50) #speed range: 0 ~ 100
    time.sleep(2)
    set_speed_INA(0)
    time.sleep(1)
    
    #speed 50, clockwise rotate for 2s
    set_speed_INB(50)
    time.sleep(2)
    set_speed_INB(0)
    time.sleep(1)