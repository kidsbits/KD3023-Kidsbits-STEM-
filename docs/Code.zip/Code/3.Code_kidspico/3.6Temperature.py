'''
 * Filename    : Temperature
 * Thonny      : Thonny 4.1.4
 * Auther      : http//www.keyestudio.com
'''
import machine
import onewire
import ds18x20
import time
 
# Connect DS18B20 to IO22.
ds18b20_pin = machine.Pin(22)
ds18b20_sensor = ds18x20.DS18X20(onewire.OneWire(ds18b20_pin))
 
roms = ds18b20_sensor.scan()

while True:
    if roms:
        # Only process the first discovered DS18B20.
        rom = roms[0]
        res = ds18b20_sensor.convert_temp()
        
        # Wait for the conversion.
        time.sleep(0.1)
        
        temp = ds18b20_sensor.read_temp(rom)
        print(temp)
    else:
        print("No DS18B20 sensor found!")