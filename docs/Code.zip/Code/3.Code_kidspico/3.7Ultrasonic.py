'''
 * Filename    : Ultrasonic
 * Thonny      : Thonny 4.1.4
 * Auther      : http//www.keyestudio.com
'''
from machine import Pin
import time

# Set ultrasonic sensor pins
Trig = Pin(21, Pin.OUT) 
Echo = Pin(27, Pin.IN)

distance = 0 # set initial distance value to 0
soundVelocity = 340 #Set the speed of sound.

# getDistance(): enable the ultrasonic sensor to detect distance
# Echo.value(): read the state of pin Echo of the ultrasonic sensor. 
# The timestamp function of the time module calculates the high-level duration of the Echo; it calculates the measured distance based on the duration and return the finnal value.
def getDistance():
    # miantain pin Trig at high level for 10us to enable the ultrasonic sensor
    Trig.value(1)
    time.sleep_us(10)
    Trig.value(0)
    # start counting: the initial time of ultrasonic wave transmitting in the air
    while Echo.value() == 0:
        Start = time.ticks_us()
    # receive the time of the reflection of the ultrasonic wave
    while Echo.value() == 1:
        Stop = time.ticks_us()
    # total time = the receiving time - the initial time
    Time = time.ticks_diff(Stop,Start)
    # Calculat the distance according to the formula: distance(m)
    # distance value devide by 100: distance(cm)
    distance =  Time * soundVelocity //2 // 10000
    # return the distance value in cm
    return distance

# print the value every 500ms
while True:    
    print('Distance: ', getDistance(), 'cm')
    time.sleep_ms(500)